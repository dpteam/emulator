# CHANGELOG


## 1.0.2
  - Added pointer cursor to the button

## 1.0.1
  - Added event 'downloadvideo' to the plugin

## 1.0.0
  - First Release
