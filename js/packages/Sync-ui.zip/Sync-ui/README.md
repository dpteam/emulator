SyncJS
=========

JavaScript middleware library which synchronizes API between browsers
